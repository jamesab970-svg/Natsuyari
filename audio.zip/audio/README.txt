Coloca aquí los archivos de música:
  chill1.mp3, chill2.mp3, chill3.mp3
  andino1.mp3, andino2.mp3, andino3.mp3
Natsu elegirá uno al azar según el género pedido.
